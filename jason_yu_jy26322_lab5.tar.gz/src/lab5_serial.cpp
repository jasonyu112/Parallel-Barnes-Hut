// lab5_mpi.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include <mpi.h>
#include "Particle.h"
#include "argparse.h"
#include "helpers.h"
#include <vector>
#include "tree.h"
#include <fstream>
#include <chrono>
#include <sstream>

int main(int argc, char* argv[])
{
    auto start = std::chrono::high_resolution_clock::now();
    struct options_t opts;
    get_opts(argc, argv, &opts);

    //read input
    std::vector<Particle*> particles;
    read_input(opts.in_file, &particles);

    //input placed into particle tree
    for (int steps = 0; steps < opts.steps; steps++) {
        //create tree

        Tree quadTree = Tree(0,4,0,4);

        //loop through particles and insert into tree
        for (Particle* p : particles) {
            if (inBoundary(p)) {
                quadTree.insert(p);
            }
        }

        for (Particle* p : particles) {
            //force calculation
            if (inBoundary(p)) {
                quadTree.compute_force(p, opts.theta);
            }
        }

        for (Particle* p : particles) {
            //update all particles positions and velocity
            if (inBoundary(p)) {
                p->updatePosAndVel(opts.dt);
            }
        }

    }

    std::ofstream myFile(opts.out_file);
    std::ostringstream buffer;
    buffer << particles.size() << std::endl;
    //free particles
    for (Particle* p : particles) {
        if (myFile.is_open()) {
            if(inBoundary(p)){
              buffer << std::scientific <<p->getIndex() << " " << p->getX() << " " << p->getY() << " " << p->getMass() << " " << p->getXVel() << " " << p->getYVel() << std::endl;
            }else{
              buffer << std::scientific <<p->getIndex() << " " << p->getX() << " " << p->getY() << " " << -1 << " " << p->getXVel() << " " << p->getYVel() << std::endl;
            }
        }
        delete p;
    }
    myFile << buffer.str();
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;
    printf("%f\n", elapsed.count());
    return 0;
}

