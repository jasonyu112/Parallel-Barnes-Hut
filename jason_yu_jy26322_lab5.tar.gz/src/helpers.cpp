#include "helpers.h"
void read_input(char* input_name, std::vector<Particle*>* particles) {
	std::ifstream in;
	in.open(input_name);
	int size;

	in >> size;
	
	for (int i = 0; i < size; i++) {
		int row;
		double x, y, mass, x_vel, y_vel;
		in >> row >> x >> y >> mass >> x_vel >> y_vel;
		Particle* p = new Particle(row, x, y, mass, x_vel, y_vel);
		particles->push_back(p);
	}
}

void readinput_mpi(char* input_name, std::vector<MPI_Particle*>* particles) {
    std::ifstream in;
    in.open(input_name);
    int size;

    in >> size;

    for (int i = 0; i < size; i++) {
        int row;
        double x, y, mass, x_vel, y_vel;
        in >> row >> x >> y >> mass >> x_vel >> y_vel;
        MPI_Particle* p = new MPI_Particle{ row, x, y, mass, x_vel, y_vel };
        particles->push_back(p);
    }
}

double calculateParticleDistance(Particle* p1, Particle* p2) {
    double x1 = p1->getX();
    double y1 = p1->getY();
    double x2 = p2->getX();
    double y2 = p2->getY();

    return sqrt(pow(x2-x1,2)+pow(y2-y1,2));
}

double calculateDistanceXY(double x1, double y1, double x2, double y2) {
    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

bool same(Particle* p1, Particle* p2) {
    return p1->getX() == p2->getX() && p1->getY() == p2->getY();
}

bool inBoundary(Particle* p) {
    return p->getX() < 4 && p->getX() > 0 && p->getY() < 4 && p->getY() > 0;
}

bool inBoundaryMPI(MPI_Particle p) {
    return p.x_pos< 4 && p.x_pos > 0 && p.y_pos < 4 && p.y_pos > 0;
}

bool sameMPI(MPI_Particle* p1, MPI_Particle* p2) {
    return p1->x_pos == p2->x_pos && p1->y_pos == p2->y_pos;
}

double calculateParticleDistanceMPI(MPI_Particle* p1, MPI_Particle* p2) {
    double x1 = p1->x_pos;
    double y1 = p1->y_pos;
    double x2 = p2->x_pos;
    double y2 = p2->y_pos;

    return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}