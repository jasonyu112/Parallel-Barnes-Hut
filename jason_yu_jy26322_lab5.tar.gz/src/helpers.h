#pragma once
#include "Particle.h"
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include "mpi_particle.h"
#include "tree.h"

void read_input(char* input_name, std::vector<Particle*>* particles);
void readinput_mpi(char* input_name, std::vector<MPI_Particle*>* particles);

double calculateParticleDistance(Particle* p1, Particle* p2);
double calculateDistanceXY(double x1, double y1, double x2, double y2);

bool same(Particle* p1, Particle* p2);
bool inBoundary(Particle* p);
bool inBoundaryMPI(MPI_Particle p);

bool sameMPI(MPI_Particle* p1, MPI_Particle* p2);
double calculateParticleDistanceMPI(MPI_Particle* p1, MPI_Particle* p2);