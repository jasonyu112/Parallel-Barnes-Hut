#include <iostream>
#include <mpi.h>
#include "mpi_particle.h"
#include "argparse.h"
#include "helpers.h"
#include <vector>
#include "Tree_mpi.h"
#include <fstream>
#include <sstream>

int main(int argc, char* argv[])
{
    int rank, size;
    double start, end; //used for timing the program later

    struct options_t opts;
    get_opts(argc, argv, &opts);

    //init MPI 
    MPI_Init(&argc, &argv);
    start = MPI_Wtime();
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    if (size == 1){
        //read input
        std::vector<Particle*> particles;
        read_input(opts.in_file, &particles);

        //input placed into particle tree
        for (int steps = 0; steps < opts.steps; steps++) {
            //create tree

            Tree quadTree = Tree(0,4,0,4);

            //loop through particles and insert into tree
            for (Particle* p : particles) {
                if (inBoundary(p)) {
                    quadTree.insert(p);
                }
            }

            for (Particle* p : particles) {
                //force calculation
                if (inBoundary(p)) {
                    quadTree.compute_force(p, opts.theta);
                }
            }

            for (Particle* p : particles) {
                //update all particles positions and velocity
                if (inBoundary(p)) {
                    p->updatePosAndVel(opts.dt);
                }
            }

        }

        std::ofstream myFile(opts.out_file);
        std::ostringstream buffer;
        buffer << particles.size() << std::endl;
        //free particles
        for (Particle* p : particles) {
            if (myFile.is_open()) {
                if(inBoundary(p)){
                buffer << std::scientific <<p->getIndex() << " " << p->getX() << " " << p->getY() << " " << p->getMass() << " " << p->getXVel() << " " << p->getYVel() << std::endl;
                }else{
                buffer << std::scientific <<p->getIndex() << " " << p->getX() << " " << p->getY() << " " << -1 << " " << p->getXVel() << " " << p->getYVel() << std::endl;
                }
            }
            delete p;
        }
        myFile << buffer.str();
        auto end = MPI_Wtime()-start;
        printf("%f\n", end);
    }
    else{
        MPI_Datatype mpi_particle_type;
        // Create MPI_Datatype for sending particles.
        MPI_Aint displacements_c[8] = {
            offsetof(MPI_Particle, index),
            offsetof(MPI_Particle, x_pos),
            offsetof(MPI_Particle, y_pos),
            offsetof(MPI_Particle, mass),
            offsetof(MPI_Particle, x_vel),
            offsetof(MPI_Particle, y_vel),
            offsetof(MPI_Particle, x_force),
            offsetof(MPI_Particle, y_force)
        };
        int block_lengths_c[8] = { 1, 1, 1, 1, 1, 1, 1, 1 };
        MPI_Datatype dtypes_c[8] = { MPI_INT, MPI_DOUBLE, MPI_DOUBLE, MPI_DOUBLE, MPI_DOUBLE, MPI_DOUBLE, MPI_DOUBLE, MPI_DOUBLE};
        MPI_Type_create_struct(8, block_lengths_c, displacements_c, dtypes_c, &mpi_particle_type);
        MPI_Type_commit(&mpi_particle_type);
        
        //read input
        std::vector<MPI_Particle*> particles;
        readinput_mpi(opts.in_file, &particles);

        MPI_Particle* particle_array = (MPI_Particle*)malloc(particles.size() * sizeof(MPI_Particle));
        if (rank == 0) {
            for (unsigned int i = 0; i < particles.size(); i++) {
                particle_array[i].index = particles[i]->index;
                particle_array[i].x_pos = particles[i]->x_pos;
                particle_array[i].y_pos = particles[i]->y_pos;
                particle_array[i].mass = particles[i]->mass;
                particle_array[i].x_vel = particles[i]->x_vel;
                particle_array[i].y_vel = particles[i]->y_vel;
                particle_array[i].x_force = particles[i]->x_force;
                particle_array[i].y_force = particles[i]->y_force;
            }
            MPI_Bcast(particle_array, particles.size(), mpi_particle_type, 0, MPI_COMM_WORLD);
        }
        else {
            MPI_Bcast(particle_array, particles.size(), mpi_particle_type, 0, MPI_COMM_WORLD);
        }
        
        MPI_Barrier(MPI_COMM_WORLD);

        for (int i = 0; i < opts.steps; i++) {
            //create tree
            Tree_MPI quadTree = Tree_MPI(0, 4, 0, 4);
            for (unsigned int j = 0; j < particles.size(); j++) {
                //insert particles into tree
                if (inBoundaryMPI(particle_array[j])) {
                    quadTree.insert(&particle_array[j]);
                }
            }

            int chunk = 0;
            int last_chunk = 0;
            if ((particles.size() / size) == 0) {
                chunk = particles.size() / size;
                last_chunk = chunk;
            }
            else {
                chunk = particles.size() / size;
                last_chunk = particles.size() - ((size - 1) * chunk);
            }
            int startpos = rank * chunk;
            int endpos = rank == (size - 1) ? particles.size() : rank * chunk + chunk;

            //compute force for every particle
            for (int index = startpos; index < endpos; index++) {
                MPI_Particle* p = &(particle_array[index]);
                if (inBoundaryMPI(particle_array[index])){
                    quadTree.compute_force(p, opts.theta);
                }
            }

            //update position and velocity of every particle
            for (int index = startpos; index < endpos; index++) {
                MPI_Particle* p = &(particle_array[index]);
                if (inBoundaryMPI(particle_array[index])) {
                    updatePosAndVel(p, opts.dt);
                }
            }

            for (int index = 0; index < size;index++) {
                int tmp_chunk = (index == (size - 1)) ? last_chunk : chunk;
                MPI_Particle* updated_particles = (MPI_Particle*)malloc(tmp_chunk * sizeof(MPI_Particle));
                if (index == rank) {
                    for (int f = 0; f < tmp_chunk; f++) {
                        int idx = rank * chunk + f;
                        updated_particles[f].index = particle_array[idx].index;
                        updated_particles[f].x_pos = particle_array[idx].x_pos;
                        updated_particles[f].y_pos = particle_array[idx].y_pos;
                        updated_particles[f].mass = particle_array[idx].mass;
                        updated_particles[f].x_vel = particle_array[idx].x_vel;
                        updated_particles[f].y_vel = particle_array[idx].y_vel;
                        updated_particles[f].x_force = particle_array[idx].x_force;
                        updated_particles[f].y_force = particle_array[idx].y_force;
                    }
                }
                MPI_Bcast(updated_particles, tmp_chunk, mpi_particle_type, index, MPI_COMM_WORLD);

                if (index != rank) {
                    for (int k = 0; k < tmp_chunk; k++) {
                        int idx = updated_particles[k].index;
                        if (particle_array[idx].index == idx) {
                            particle_array[idx].x_pos = updated_particles[k].x_pos;
                            particle_array[idx].y_pos = updated_particles[k].y_pos;
                            particle_array[idx].mass = updated_particles[k].mass;
                            particle_array[idx].x_vel = updated_particles[k].x_vel;
                            particle_array[idx].y_vel = updated_particles[k].y_vel;
                            particle_array[idx].x_force = updated_particles[k].x_force;
                            particle_array[idx].y_force = updated_particles[k].y_force;
                        }
                    }
                }
                free(updated_particles);
            }
            
            MPI_Barrier(MPI_COMM_WORLD);
        }
        //writing to file when finished
        if (rank == 0) {
            std::ofstream myFile(opts.out_file);
            if (myFile.is_open()) {
                std::ostringstream buffer;
                buffer << particles.size() << std::endl;
                for (unsigned int i = 0; i < particles.size(); i++) {
                    if (inBoundaryMPI(particle_array[i])){
                        buffer<<std::scientific << particle_array[i].index << " "
                            << particle_array[i].x_pos << " "
                            << particle_array[i].y_pos << " "
                            << particle_array[i].mass << " "
                            << particle_array[i].x_vel << " "
                            << particle_array[i].y_vel << std::endl;
                    }else{
                        buffer<<std::scientific << particle_array[i].index << " "
                            << particle_array[i].x_pos << " "
                            << particle_array[i].y_pos << " "
                            << -1 << " "
                            << particle_array[i].x_vel << " "
                            << particle_array[i].y_vel << std::endl;
                    }
                }
                myFile << buffer.str();
            }
        }
        free(particle_array);
        //free particles
        for (MPI_Particle* p : particles) {
            delete p;
        }
        end = MPI_Wtime()- start;
        if (rank == 0) printf("%f\n", end);
    }

    MPI_Finalize();
    return 0;
}

